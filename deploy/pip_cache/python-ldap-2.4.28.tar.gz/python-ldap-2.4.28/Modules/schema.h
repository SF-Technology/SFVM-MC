/* See http://www.python-ldap.org/ for details.
 * $Id: schema.h,v 1.5 2009/04/17 12:19:09 stroeder Exp $ */

#ifndef __h_schema_
#define __h_schema_



#include "common.h"
extern void LDAPinit_schema( PyObject* );


#endif /* __h_schema_ */

