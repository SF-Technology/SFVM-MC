* gevent version:
* Python version:
* Operating System:

### Description:

```
// REPLACE ME: What are you trying to get done, what has happened, what went wrong, and what did you expect?
```

### What I've run:

```
// REPLACE ME: Paste short, self contained, correct example code (sscce.org), tracebacks, etc, here
```
